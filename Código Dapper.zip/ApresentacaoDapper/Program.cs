﻿using Dapper;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;


namespace ApresentacaoDapper
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string stringConexao = "";

            // Inserir(stringConexao);
            // Consulta(stringConexao);
            // MappingConsulta(stringConexao);
            // Atualizar(stringConexao);
            // Remover(stringConexao);
        }

        static void Inserir(string StringConexao)
        {
            using (var conexao = new SqlConnection(StringConexao))
            {
                conexao.Open();

                var diretor = new Diretor
                {
                    Id = 1,
                    Nome = "Vinicius Rosalen"
                };

                string QueryInserirDiretor = @"
                INSERT INTO [dbo].[Diretor] ([Id], [nome])
                VALUES (@Id, @Nome)";

                conexao.Execute(QueryInserirDiretor, diretor);

                var filme = new Filme
                {
                    Id = 1,
                    Nome = "Filme legal de POO",
                    Duracao = 127.5,
                    Id_Diretor = 1
                };

                string QueryInserirFilme = @"
                INSERT INTO [dbo].[Filme] ([Id], [nome], [duracao], [id_diretor])
                VALUES (@Id, @Nome, @Duracao, @Id_Diretor)";

                conexao.Execute(QueryInserirFilme, filme);

                Console.WriteLine("Dados inseridos no banco de dados!");
            }
        }

        static void Consulta(string StringConexao)
        {
            using (var conexao = new SqlConnection(StringConexao))
            {
                conexao.Open();

                string QuerySelecionarDiretor = "SELECT [Id], [nome] FROM [dbo].[Diretor]";
                IEnumerable<Diretor> diretores = conexao.Query<Diretor>(QuerySelecionarDiretor);

                Console.WriteLine("Diretores:");
                foreach (var diretor in diretores)
                {
                    Console.WriteLine($"Id: {diretor.Id}, Nome: {diretor.Nome}");
                }

                string QuerySelecionarFilme = @"
                SELECT f.[Id], f.[nome], f.[duracao], f.[id_diretor]
                FROM [dbo].[Filme] f
                INNER JOIN [dbo].[Diretor] d ON f.[id_diretor] = d.[Id]";

                IEnumerable<Filme> filmes = conexao.Query<Filme>(QuerySelecionarFilme);

                Console.WriteLine("\nFilmes:");
                foreach (var filme in filmes)
                {
                    Console.WriteLine($"Id: {filme.Id}, Nome: {filme.Nome}, Duração: {filme.Duracao}h, Id_Diretor: {filme.Id_Diretor}");
                }
            }
        }

        static void MappingConsulta(string StringConexao)
        {
            using (var conexao = new SqlConnection(StringConexao))
            {
                conexao.Open();

                string query = @"
                SELECT 
                    f.[Id] AS Id, 
                    f.[nome] AS Nome, 
                    f.[duracao] AS Duracao, 
                    f.[id_diretor] AS IdDiretor,
                    d.[Id] AS Id, 
                    d.[nome] AS Nome
                FROM [dbo].[Filme] f
                LEFT JOIN [dbo].[Diretor] d ON f.[id_diretor] = d.[Id]";

                var filmes = conexao.Query<Filme, Diretor, Filme>(
                    query,
                    (filme, diretor) =>
                    {
                        if (diretor != null && diretor.Id > 0)
                        {
                            filme.Diretor = diretor;
                        }
                        return filme;
                    },
                    splitOn: "Id"
                );

                foreach (var filme in filmes)
                {
                    Console.WriteLine($"Filme: {filme.Nome}, Duração: {filme.Duracao}, Diretor: {filme.Diretor?.Nome ?? "Sem Diretor"}");
                }
            }
        }

        static void Atualizar(string StringConexao)
        {
            using (var conexao = new SqlConnection(StringConexao))
            {
                conexao.Open();

                using (var transacao = conexao.BeginTransaction())
                {
                    try
                    {
                        string QueryAtualizarFilme = @"
                        UPDATE [dbo].[Filme]
                        SET [nome] = @Nome
                        WHERE [Id] = @Id";

                        conexao.Execute(QueryAtualizarFilme,
                            new { Nome = "Novo filme de POO", Id = 1 },
                            transaction: transacao);

                        string QueryAtualizarDiretor = @"
                        UPDATE [dbo].[Diretor]
                        SET [nome] = @Nome
                        WHERE [Id] = @Id";

                        conexao.Execute(QueryAtualizarDiretor,
                            new { Nome = "Vinicius Rosalen da Silva", Id = 1 },
                            transaction: transacao);

                        transacao.Commit();

                        Console.WriteLine("Dados atualizados com sucesso!");
                    }
                    catch (Exception ex)
                    {
                        transacao.Rollback();
                        Console.WriteLine($"Erro: {ex.Message}");
                    }
                }
            }
        }

        static void Remover(string StringConexao)
        {
            using (var conexao = new SqlConnection(StringConexao))
            {
                conexao.Open();

                using (var transacao = conexao.BeginTransaction())
                {
                    try
                    {
                        string deleteFilmeQuery = @"
                        DELETE FROM [dbo].[Filme]
                        WHERE [nome] = @Nome AND [id_diretor] = @IdDiretor";

                        conexao.Execute(deleteFilmeQuery,
                            new { Nome = "Novo filme de POO", IdDiretor = 1 },
                            transaction: transacao);

                        string deleteDiretorQuery = @"
                        DELETE FROM [dbo].[Diretor]
                        WHERE [nome] = @Nome";

                        conexao.Execute(deleteDiretorQuery,
                            new { Nome = "Vinicius Rosalen da Silva" },
                            transaction: transacao);

                        transacao.Commit();

                        Console.WriteLine("Dados removidos com sucesso!");
                    }
                    catch (Exception ex)
                    {
                        transacao.Rollback();
                        Console.WriteLine($"Erro: {ex.Message}");
                    }
                }
            }
        }
    }

    public class Filme
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public double? Duracao { get; set; }
        public int? Id_Diretor { get; set; }
        public Diretor Diretor { get; set; }
    }

    public class Diretor
    {
        public int Id { get; set; }
        public string Nome { get; set; }
    }
}
